/*
MAIN
*/
package tienda_ropa;


public class Tienda_ropa {

    
    public static void main(String[] args) {
        System.out.println("Bienvenido a la tienda de ropa Y3");
        //Crear las instancias de las clases= crear objetos.
        //NombreCLase nombreObjeto = new NombreClase("Argumentos..", );
        Ropa prenda1 = new Ropa("Q012393","Dove long sleeve","Yeezy Gap engineered by Balenciaga","Polera", true);
        Ropa prenda2 = new Ropa("K92331","Round jacket v2","Yeezy Gap engineered by Balenciaga","Chaqueta", true);
        //Clientes
        Cliente cliente1 = new Cliente("CL33312","joe biden");
        Cliente cliente2 = new Cliente("CL33444","Juani toledo");
        //Proveedores
        ProveedorDeModa proveedor1 = new ProveedorDeModa("P233662","Gap");
        ProveedorDeModa proveedor2 = new ProveedorDeModa("P73252","LosAngelesApparel");
        //Crear un objeto SDGI
        SistemaGestionInventarios sistema = new SistemaGestionInventarios();
        
        //Registrar prendas
        sistema.registrarPrenda(prenda1);
        sistema.registrarPrenda(prenda2);
        //Registrar Clientes 
        sistema.registrarCliente(cliente1);
        sistema.registrarCliente(cliente2);
        //Registrar proveedores
        sistema.registrarProveedor(proveedor1);
        sistema.registrarProveedor(proveedor2);     
        //Simular una compra
        cliente1.realizarCompra(prenda1);
        cliente2.realizarCompra(prenda2);
        //Simular devolucion
        cliente1.devolverPrenda(prenda1);
        cliente2.devolverPrenda(prenda2);
        //Proveedor suministra prenda
        proveedor1.suministrarPrenda(prenda1);
        proveedor2.suministrarPrenda(prenda2);
        //Verificar la disponibilidad de una prenda 
        sistema.verificarDisponibilidad(prenda1);
        sistema.verificarDisponibilidad(prenda2);
        
        //Metodo gener informa
        sistema.generarInformeVentas();
    }
    
}
