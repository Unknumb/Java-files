
package tienda_ropa;


public class SistemaGestionInventarios {
    //atributos
    private String catalogoPrendas, clientesRegistrados, proveedoresActivos;
    
    // Metodos
    public void registrarPrenda(Ropa prenda){
        catalogoPrendas = prenda.getInfo();//Guardando la informacion de las prendas 
        System.out.println("Prenda registrada: "+ catalogoPrendas);
    }
    //metodo registrar cliente
    public void registrarCliente(Cliente cliente){
        clientesRegistrados = "Cliente: " + cliente.getInfo();
        System.out.println("Cliente registrado" + clientesRegistrados);
    }
    //Metodo para registrar un proveedor 
    public void registrarProveedor(ProveedorDeModa proveedor){
        proveedoresActivos = "proveedor: " + proveedor.getInfo();
        System.out.println("Proveedor registrado" + proveedoresActivos);
    }
    //Metodo verificar disponibilidad de la prenda
    public void verificarDisponibilidad(Ropa prenda){
        System.out.println("Verificando disponibilidad..."+ prenda.getInfo());
    }
    //Metodo para generar informe de ventas
    public void generarInformeVentas(){
        System.out.println("Generando el informe...");
        //Aca va la logico para generar el informe
    }
}
