
package tienda_ropa;


public class Ropa {
    
    //Atributos
    private String codigo, nombre , marco, categoria;
    private Boolean disponibilidad;
    
    //Constructores

    public Ropa(String codigo, String nombre, String marco, String categoria, Boolean disponibilidad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.marco = marco;
        this.categoria = categoria;
        this.disponibilidad = disponibilidad;
    }
    
    //Metodo vender
    public void vender(){
        if (disponibilidad){
            System.out.println("La prenda esta disponible." + nombre);
            //Pasa a ser false por que si el codigo pasa por aqui, la prenda se vendio.
            disponibilidad = false;
        }else{
            System.out.println("Lo sentimos, esta prenda ya no se encuentra disponible.");
        }
    }
    
    //METODO REPONER INVENTARIO
    public void reponerInventario(){
        disponibilidad = true;
        System.out.println("La prenda, vuelve a estar disponible." + nombre);
    }
    
    //Consultar todos los datos de la prenda.
    public String getInfo(){
        return "Codigo: " + codigo + ", Nombre: " + nombre + ", Marca: " + marco + ", categoria: " + categoria + ", disponibilidad: " + (disponibilidad ? "Si" : "No") ; 
    }
    
    
}


