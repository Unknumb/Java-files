
package tienda_ropa;


public class ProveedorDeModa {
    //atributos
    private String codigoProveedor, nombre, prendasSuministradas;
    
    //constructor

    public ProveedorDeModa(String codigoProveedor, String nombre) {
        this.codigoProveedor = codigoProveedor;
        this.nombre = nombre;
        this.prendasSuministradas = "";
    }
    //metodos para suministrar prendas
    public void suministrarPrenda(Ropa prenda){
        prendasSuministradas = prenda.getInfo();
        System.out.println(nombre + "ha suministrado: "+ prendasSuministradas);
    }
    //metodo getInfo
    public String getInfo(){
        return "codigo del proveedor: "+ codigoProveedor +"nombre proveedor: " + nombre +"Prendas suministradas: "+ prendasSuministradas;
    }
    
    
}
