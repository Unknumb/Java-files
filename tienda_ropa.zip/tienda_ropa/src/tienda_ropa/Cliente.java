
package tienda_ropa;


public class Cliente {
    //ATRIBUTOS
    private String numeroCliente, nombre, prendasAdquiridas;
    
    //constructor 

    public Cliente(String numeroCliente, String nombre) {
        this.numeroCliente = numeroCliente;
        this.nombre = nombre;
        this.prendasAdquiridas = "";
    }
    
    //Metodo para realizar la compra
    public void realizarCompra(Ropa prenda){
        prenda.vender();//Para que no me marque la prenda como disponible.
        prendasAdquiridas = prenda.getInfo();
        System.out.println(nombre + "ha comprado: " + prendasAdquiridas);        
    }
    //Metodo de devolver prenda
    public void devolverPrenda(Ropa prenda){
        if (!prendasAdquiridas.isEmpty()){
        //Llamo al metodo para que la prenda se reponga en la tienda
            prenda.reponerInventario();
            System.out.println(nombre + "ha devuelto la prenda: " + prendasAdquiridas);
            prendasAdquiridas = "";//Reseteando las prendas del cliente a vacio;
    
        }else{
            System.out.println("no ha adquirido la prenda");
        }
         
    }
    public String getInfo(){
        return "Numero cliente: " + numeroCliente + ", Nombre: " + nombre + " prendas adquiridas: " + prendasAdquiridas;
    }
     
    
}
