/*
  MAIN
 */
package gestionEstudiante;
import java.util.Scanner;

public class GestionEstudiantes {

    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicitar al usuario que ingrese sus datos
        System.out.println("Ingrese su numero de matricula:");
        String matricula = scanner.nextLine();

        System.out.println("Ingrese su nombre:");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese su nota final");
        double notaFinal = scanner.nextDouble();
        
        //crear una instancia de nota final
        Estudiante estudiante = new Estudiante(matricula, nombre, notaFinal);
        
        //Mostar la informacion del estudiante
        System.out.println("Informacion de estudiante: ");
        System.out.println(estudiante.getInfo());
        
        // Verificar si  el estudiante ha aprobado
        if (estudiante.haAprobado()) {
            System.out.println("Felicidades, has aprobado.");
        }else{
            System.out.println("lo siento, no has aprobado");
        }
    }
    
    
}
