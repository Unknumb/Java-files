
package gestionEstudiante;
public class Estudiante {
    //Atributos de la clase estudiante
    private String matricula, nombre;
    private double notaFinal;
    
    //constructores

    public Estudiante(String matricula, String nombre, double notaFinal) {
        this.matricula = matricula;
        this.nombre = nombre;
        this.notaFinal = notaFinal;
    }
    //Metodo para obtener la informacion del estudiante
    public String getInfo(){
        return "Matricula: " + matricula + "Nombre: " + nombre + "Nota final: " + notaFinal;
    }
    //Metodo para verificar si paso de curso o no
    public boolean haAprobado(){
        if (notaFinal >= 4){
            return true;
        }
        else{
            return false;
        }   
    }
    
    
    
}
